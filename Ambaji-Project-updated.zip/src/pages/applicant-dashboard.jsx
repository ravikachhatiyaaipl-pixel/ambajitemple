import { useState, useEffect, useMemo } from "react";
import axios from "axios";
import { toast } from "react-hot-toast";
import {
    Store,
    MapPin,
    Building2,
    Ruler,
    LogOut,
    RefreshCw,
    FileText,
    Clock,
    CheckCircle2,
    AlertCircle,
    ChevronDown,
    Search,
    Hourglass,
    KeyRound,
    XCircle,
} from "lucide-react";
import {
    PortalPage, PortalLoader, HeroBanner, HeroButton, StatCard, StatGrid, Panel,
    TrendChart, BarsChart, DonutChart, EmptyState, Badge, ProgressRow, stageKind,
    countBy, monthlyCounts, greeting, todayLabel, CREAM,
} from "../components/dashboard/portalkit";

const ApplicantDashboard = ({ user, onLogout }) => {
    const [shops, setShops] = useState([]);
    const [rentals, setRentals] = useState([]);
    const [applications, setApplications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [applyFor, setApplyFor] = useState(null);
    const [submitting, setSubmitting] = useState(false);
    const [form, setForm] = useState({
        SPR_Id: "",
        Busi_Name: "",
        Busi_Type: "",
        SPR_StDt: "",
        SPR_Dura: "",
        SPRA_Reason: "",
        SPRA_Remark: "",
    });

    const displayName = user?.name || user?.username || "Applicant";
    const email = user?.email || "";

    const fetchAll = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem("auth_token");
            const headers = { Authorization: `Bearer ${token}` };
            const base = import.meta.env.VITE_API_URL;

            const [shopRes, rentRes, appRes] = await Promise.all([
                axios.get(`${base}/applicant/available-shops`, { headers }),
                axios.get(`${base}/applicant/rentals`, { headers }),
                axios.get(`${base}/applicant/my-applications`, { headers }),
            ]);

            if (shopRes.data.success) setShops(shopRes.data.data || []);
            if (rentRes.data.success) setRentals(rentRes.data.data || []);
            if (appRes.data.success) setApplications(appRes.data.data || []);
        } catch (error) {
            console.error("Applicant dashboard load failed:", error);
            toast.error(
                error.response?.data?.message || "Failed to load dashboard data"
            );
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAll();
    }, []);

    const openApply = (shop) => {
        setApplyFor(shop);
        setForm({
            SPR_Id: shop?.rental?.SPR_Id || "",
            Busi_Name: "",
            Busi_Type: "",
            SPR_StDt: "",
            SPR_Dura: "",
            SPRA_Reason: "",
            SPRA_Remark: "",
        });
    };

    const submitApplication = async (e) => {
        e.preventDefault();

        if (!form.Busi_Name.trim()) {
            toast.error("Please enter business name");
            return;
        }

        try {
            setSubmitting(true);
            const token = localStorage.getItem("auth_token");
            const response = await axios.post(
                `${import.meta.env.VITE_API_URL}/applicant/apply`,
                form,
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (response.data.success) {
                toast.success("Application submitted! Admin will review it.");
                setApplyFor(null);
                fetchAll();
            } else {
                toast.error(response.data.message || "Failed to submit application");
            }
        } catch (error) {
            if (error.response?.data?.errors) {
                const msgs = Object.values(error.response.data.errors).flat();
                toast.error(msgs.join(", "));
            } else {
                toast.error(error.response?.data?.message || "Failed to submit");
            }
        } finally {
            setSubmitting(false);
        }
    };

    const statusOf = (app) => {
        if (app.status?.stage) return app.status.stage;
        if (app.SPRA_Status) return "Pending";
        return "Submitted";
    };

    const [query, setQuery] = useState("");

    const stageCounts = useMemo(
        () => countBy(applications, (a) => statusOf(a)),
        [applications]
    );
    const approvedCount = applications.filter((a) => stageKind(statusOf(a)) === "success").length;
    const rejectedCount = applications.filter((a) => stageKind(statusOf(a)) === "danger").length;
    const pendingCount = applications.length - approvedCount - rejectedCount;
    const appsByMonth = useMemo(
        () => monthlyCounts(applications, (a) => a.SPRA_Date, 6),
        [applications]
    );
    const shopsByBuilding = useMemo(
        () => countBy(shops, (s) => s.SPM_Bldg || "Other").slice(0, 8),
        [shops]
    );
    const rentCompare = useMemo(
        () =>
            shops
                .filter((s) => s.rental)
                .slice(0, 8)
                .map((s) => ({
                    label: s.SPM_Code || s.SPM_Name || "Shop",
                    rent: Number(s.rental.SPR_BsRnt) || 0,
                    deposit: Number(s.rental.SPR_SDMnt) || 0,
                })),
        [shops]
    );
    const filteredShops = shops.filter((s) =>
        `${s.SPM_Name || ""} ${s.SPM_Code || ""} ${s.SPM_Loca || ""} ${s.SPM_Bldg || ""}`
            .toLowerCase()
            .includes(query.trim().toLowerCase())
    );

    if (loading) return <PortalLoader text="Loading your portal..." />;

    return (
        <div className="min-h-screen" style={{ background: CREAM }}>
            {/* Top bar */}
            <header className="sticky top-0 z-20 border-b border-red-100 bg-white/95 backdrop-blur">
                <div className="mx-auto flex max-w-full items-center justify-between px-4 py-3 sm:px-6">
                    <div className="flex items-center gap-3">
                        <img src="/ambajilogo.png" alt="Ambaji Temple" className="h-10 w-10 object-contain" />
                        <div>
                            <p className="text-sm font-bold leading-tight text-gray-900">Applicant Portal</p>
                            <p className="text-[11px] leading-tight text-gray-500">Shree Ambaji Mata Temple Trust</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="hidden text-right sm:block">
                            <p className="text-sm font-medium text-gray-900">{displayName}</p>
                            <p className="text-xs text-gray-500">{email}</p>
                        </div>
                        <button onClick={fetchAll} title="Refresh"
                            className="rounded-lg border border-gray-300 bg-white p-2 hover:bg-gray-50">
                            <RefreshCw className="h-4 w-4 text-gray-600" />
                        </button>
                        <button onClick={onLogout}
                            className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700">
                            <LogOut className="h-4 w-4" /> Logout
                        </button>
                    </div>
                </div>
            </header>

            <PortalPage>
                <HeroBanner
                    eyebrow={todayLabel()}
                    title={`${greeting()}, ${displayName}`}
                    subtitle="Apply for temple shops and track every application in one place"
                    actions={
                        <HeroButton solid icon={Store}
                            onClick={() => document.getElementById("available-shops")?.scrollIntoView({ behavior: "smooth" })}>
                            Browse shops
                        </HeroButton>
                    }
                />

                {/* Stats */}
                <StatGrid cols={5}>
                    <StatCard label="Available Shops" value={shops.length} sub="Open for application" icon={Store} tone="red" />
                    <StatCard label="My Applications" value={applications.length} sub="Total submitted" icon={FileText} tone="teal" />
                    <StatCard label="Approved" value={approvedCount} sub="Ready to proceed" icon={CheckCircle2} tone="green" />
                    <StatCard label="In Review" value={pendingCount} sub="Awaiting decision" icon={Hourglass} tone="gold" />
                    <StatCard label="Active Rentals" value={rentals.length} sub="Shops allotted" icon={KeyRound} tone="slate" />
                </StatGrid>

                {/* Charts */}
                <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
                    <Panel title="Application Status" subtitle="Where your applications stand">
                        <DonutChart data={stageCounts} centerValue={applications.length} centerLabel="applications" />
                    </Panel>
                    <Panel title="Applications Over Time" subtitle="Last 6 months" className="lg:col-span-2">
                        {applications.length === 0 ? (
                            <EmptyState icon={FileText} text="Submit an application to see your activity" />
                        ) : (
                            <TrendChart data={appsByMonth} money={false} series={[{ key: "value", name: "Applications", color: "#E53935" }]} />
                        )}
                    </Panel>
                </div>

                <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
                    <Panel title="Base Rent vs Security Deposit" subtitle="Available shops with a rental entry" className="lg:col-span-2">
                        <BarsChart data={rentCompare} money
                            bars={[
                                { key: "rent", name: "Base rent", color: "#E53935" },
                                { key: "deposit", name: "Security", color: "#F5B800" },
                            ]} />
                    </Panel>
                    <Panel title="Shops by Building" subtitle="Where space is available">
                        <BarsChart data={shopsByBuilding} bars={[{ key: "value", name: "Shops", color: "#B71C1C" }]} horizontal />
                    </Panel>
                </div>

                <Panel title="Approval Overview">
                    <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
                        <ProgressRow label="Approved" value={approvedCount} total={applications.length} color="#059669" />
                        <ProgressRow label="In review" value={pendingCount} total={applications.length} color="#F5B800" />
                        <ProgressRow label="Rejected" value={rejectedCount} total={applications.length} color="#B71C1C" />
                    </div>
                </Panel>

                {/* Available Shops */}
                <div id="available-shops">
                    <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                        <div>
                            <h2 className="text-lg font-semibold text-gray-900">Available Shops</h2>
                            <p className="text-sm text-gray-500">Apply for any available shop. Admin will review your application.</p>
                        </div>
                        <div className="relative w-full sm:w-72">
                            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
                            <input
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                placeholder="Search by name, code or location"
                                className="w-full rounded-lg border border-gray-300 bg-white py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                            />
                        </div>
                    </div>

                    {filteredShops.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-gray-300 bg-white py-12 text-center">
                            <Store className="mx-auto h-10 w-10 text-gray-300" />
                            <p className="mt-3 text-sm text-gray-500">
                                {shops.length === 0 ? "No shops available right now" : "No shops match your search"}
                            </p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
                            {filteredShops.map((shop) => (
                                <div key={shop.SPM_Id}
                                    className="flex flex-col rounded-2xl border border-gray-100 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
                                    <div className="flex items-start justify-between gap-2">
                                        <div className="flex items-center gap-2">
                                            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-50">
                                                <Store className="h-5 w-5 text-red-600" />
                                            </div>
                                            <h3 className="text-sm font-semibold text-gray-900">{shop.SPM_Name || "Shop"}</h3>
                                        </div>
                                        <Badge kind="neutral">{shop.SPM_Code}</Badge>
                                    </div>

                                    <div className="mt-3 space-y-1.5 text-xs text-gray-600">
                                        {shop.SPM_Loca && (
                                            <div className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 text-gray-400" />{shop.SPM_Loca}</div>
                                        )}
                                        {shop.SPM_Bldg && (
                                            <div className="flex items-center gap-1.5">
                                                <Building2 className="h-3.5 w-3.5 text-gray-400" />
                                                {shop.SPM_Bldg}{shop.SPM_Unit ? ` - Unit ${shop.SPM_Unit}` : ""}
                                            </div>
                                        )}
                                        {shop.SPM_SqFt && (
                                            <div className="flex items-center gap-1.5"><Ruler className="h-3.5 w-3.5 text-gray-400" />{shop.SPM_SqFt} sq.ft</div>
                                        )}
                                    </div>

                                    {shop.rental && (
                                        <div className="mt-3 mb-4 grid grid-cols-3 gap-2 rounded-xl px-3 py-2 text-center" style={{ background: CREAM }}>
                                            <div><p className="text-[10px] text-gray-500">Base Rent</p><p className="text-xs font-semibold text-gray-900">₹{shop.rental.SPR_BsRnt ?? "0"}</p></div>
                                            <div><p className="text-[10px] text-gray-500">Security</p><p className="text-xs font-semibold text-gray-900">₹{shop.rental.SPR_SDMnt ?? "0"}</p></div>
                                            <div><p className="text-[10px] text-gray-500">Late Fee</p><p className="text-xs font-semibold text-gray-900">₹{shop.rental.SPR_LtFe ?? "0"}</p></div>
                                        </div>
                                    )}

                                    <div className="mt-auto border-t border-gray-100 pt-3">
                                        {shop.already_applied ? (
                                            <button disabled className="inline-flex w-full cursor-not-allowed items-center justify-center gap-2 rounded-lg bg-gray-100 px-3 py-2 text-sm font-medium text-gray-500">
                                                <CheckCircle2 className="h-4 w-4" /> Already Applied
                                            </button>
                                        ) : (
                                            <button onClick={() => openApply(shop)} className="w-full rounded-lg bg-red-600 px-3 py-2 text-sm font-medium text-white hover:bg-red-700">
                                                Apply for this Shop
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* My Applications */}
                <div>
                    <h2 className="text-lg font-semibold text-gray-900">My Applications</h2>
                    <p className="mb-4 text-sm text-gray-500">Track status of applications you submitted.</p>

                    {applications.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-gray-300 bg-white py-12 text-center">
                            <FileText className="mx-auto h-10 w-10 text-gray-300" />
                            <p className="mt-3 text-sm text-gray-500">You have not applied for any shop yet</p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {applications.map((app) => {
                                const stage = statusOf(app);
                                const kind = stageKind(stage);
                                return (
                                    <div key={app.SPRA_Id} className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
                                        <div className="flex flex-wrap items-start justify-between gap-3">
                                            <div>
                                                <div className="flex flex-wrap items-center gap-2">
                                                    <FileText className="h-4 w-4 text-red-600" />
                                                    <span className="text-sm font-semibold text-gray-900">{app.Busi_Name}</span>
                                                    {app.Busi_Type && <Badge kind="neutral">{app.Busi_Type}</Badge>}
                                                </div>
                                                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-gray-500">
                                                    <Clock className="h-3.5 w-3.5" />
                                                    Applied on {app.SPRA_Date ? new Date(app.SPRA_Date).toLocaleDateString("en-IN") : "-"}
                                                </div>
                                            </div>
                                            <Badge kind={kind}>
                                                {kind === "success" ? <CheckCircle2 className="h-3.5 w-3.5" /> : kind === "danger" ? <XCircle className="h-3.5 w-3.5" /> : <AlertCircle className="h-3.5 w-3.5" />}
                                                {stage}
                                            </Badge>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </PortalPage>

            {/* Apply Modal */}
            {applyFor && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="w-full max-w-lg rounded-xl bg-white shadow-xl overflow-hidden">
                        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
                            <div>
                                <h3 className="text-base font-semibold text-gray-900">
                                    Apply for Shop
                                </h3>
                                <p className="text-xs text-gray-500 mt-0.5">
                                    {applyFor.SPM_Name} ({applyFor.SPM_Code})
                                </p>
                            </div>
                            <button
                                onClick={() => setApplyFor(null)}
                                className="text-gray-400 hover:text-gray-600"
                            >
                                <ChevronDown className="h-5 w-5 rotate-45" />
                            </button>
                        </div>

                        <form onSubmit={submitApplication} className="px-5 py-4 space-y-4">
                            <input type="hidden" value={form.SPR_Id} readOnly />

                            {!form.SPR_Id && (
                                <p className="rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-800">
                                    Is shop ki rental entry abhi available nahi hai. Admin se
                                    sampark karein.
                                </p>
                            )}

                            {/* Applicant auto-filled hoga */}
                            <div className="rounded-lg bg-gray-50 px-3 py-2.5">
                                <p className="text-xs text-gray-500">Applicant (auto)</p>
                                <p className="text-sm font-medium text-gray-900">
                                    {displayName}
                                    {email ? ` · ${email}` : ""}
                                </p>
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                    Business Name *
                                </label>
                                <input
                                    type="text"
                                    value={form.Busi_Name}
                                    onChange={(e) =>
                                        setForm((p) => ({ ...p, Busi_Name: e.target.value }))
                                    }
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                                    placeholder="Enter business name"
                                    maxLength={100}
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                    Business Type
                                </label>
                                <input
                                    type="text"
                                    value={form.Busi_Type}
                                    onChange={(e) =>
                                        setForm((p) => ({ ...p, Busi_Type: e.target.value }))
                                    }
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                                    placeholder="e.g. Grocery, Garments, Restaurant"
                                    maxLength={150}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                        Start Date
                                    </label>
                                    <input
                                        type="date"
                                        value={form.SPR_StDt}
                                        onChange={(e) =>
                                            setForm((p) => ({ ...p, SPR_StDt: e.target.value }))
                                        }
                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                        Duration (Years)
                                    </label>
                                    <input
                                        type="number"
                                        min="1"
                                        step="1"
                                        value={form.SPR_Dura}
                                        onChange={(e) =>
                                            setForm((p) => ({ ...p, SPR_Dura: e.target.value }))
                                        }
                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                                        placeholder="e.g. 5"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                    Reason
                                </label>
                                <input
                                    type="text"
                                    value={form.SPRA_Reason}
                                    onChange={(e) =>
                                        setForm((p) => ({ ...p, SPRA_Reason: e.target.value }))
                                    }
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                                    placeholder="Why do you want this shop?"
                                    maxLength={255}
                                />
                            </div>

                            <div>
                                <label className="block text-xs font-medium text-gray-700 mb-1.5">
                                    Remarks
                                </label>
                                <textarea
                                    value={form.SPRA_Remark}
                                    onChange={(e) =>
                                        setForm((p) => ({ ...p, SPRA_Remark: e.target.value }))
                                    }
                                    rows={2}
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500 resize-none"
                                    placeholder="Any additional information"
                                    maxLength={255}
                                />
                            </div>

                            <div className="flex gap-3 pt-2">
                                <button
                                    type="button"
                                    onClick={() => setApplyFor(null)}
                                    className="flex-1 rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={submitting || !form.SPR_Id}
                                    className="flex-1 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60"
                                >
                                    {submitting ? "Submitting..." : "Submit Application"}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ApplicantDashboard;