/***
 *
 *  Application Name: I3EMS
 *
 *  Developed By: Aark InfoSoft Pvt Ltd.
 *
 *  Version: Ambaji Mata Temple Management
 *
 *  All Rights Reserved, Unauthorized use, copying, or distribution is strictly prohibited.
 *  All source code, database structures, UI/UX designs, workflows,
 *  business logic, and documentation are confidential intellectual property.
 *  Reverse engineering, duplication, or redistribution without written permission
 *  is strictly prohibited and may result in legal action.
 *
 */

import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "react-hot-toast";
import {
  User,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Building,
  UserPlus,
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  CheckCircle,
  Check,
  Key,
} from "lucide-react";
import Swal from "sweetalert2";
import axios from "axios";

const Registration = () => {
  const [formData, setFormData] = useState({
    Usr_Name: "",
    Usr_Email: "",
    Usr_Mobile: "",
    Usr_Pas: "",
    Usr_Pas_confirmation: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [step, setStep] = useState(1);

  const navigate = useNavigate();

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkScreenSize();
    window.addEventListener("resize", checkScreenSize);
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  // Department selection removed from registration - admin will map departments later.

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type == "checkbox" ? checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  const validateStep = (stepNumber) => {
    const newErrors = {};

    if (stepNumber == 1) {
      if (!formData.Usr_Name?.trim()) {
        newErrors.Usr_Name = "Username is required";
      } else if (formData.Usr_Name.length > 50) {
        newErrors.Usr_Name = "Maximum 50 characters allowed";
      }

      if (!formData.Usr_Email?.trim()) {
        newErrors.Usr_Email = "Email is required";
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.Usr_Email)) {
        newErrors.Usr_Email = "Invalid email format";
      } else if (formData.Usr_Email.length > 100) {
        newErrors.Usr_Email = "Maximum 100 characters allowed";
      }

      if (!formData.Usr_Mobile?.trim()) {
        newErrors.Usr_Mobile = "Mobile number is required";
      } else if (formData.Usr_Mobile.length > 15) {
        newErrors.Usr_Mobile = "Maximum 15 characters allowed";
      }
    }

    if (stepNumber == 2) {
      if (!formData.Usr_Pas?.trim()) {
        newErrors.Usr_Pas = "Password is required";
      } else if (formData.Usr_Pas.length < 8) {
        newErrors.Usr_Pas = "Minimum 8 characters required";
      }
      if (!formData.Usr_Pas_confirmation?.trim()) {
        newErrors.Usr_Pas_confirmation = "Confirm password is required";
      } else if (formData.Usr_Pas != formData.Usr_Pas_confirmation) {
        newErrors.Usr_Pas_confirmation = "Passwords do not match";
      }
    }

    if (stepNumber == 3) {
      if (!acceptTerms) {
        newErrors.terms = "You must accept the terms and conditions";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length == 0;
  };

  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePreviousStep = () => {
    setStep(step - 1);
    window.scrollTo(0, 0);
  };

  const generatePassword = () => {
    const length = 12;
    const charset =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let password = "";

    password += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[Math.floor(Math.random() * 26)];
    password += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)];
    password += "0123456789"[Math.floor(Math.random() * 10)];
    password += "!@#$%^&*"[Math.floor(Math.random() * 8)];

    for (let i = 4; i < length; i++) {
      password += charset[Math.floor(Math.random() * charset.length)];
    }

    password = password
      .split("")
      .sort(() => Math.random() - 0.5)
      .join("");

    setFormData((prev) => ({
      ...prev,
      Usr_Pas: password,
      Usr_Pas_confirmation: password,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateStep(3)) {
      return;
    }

    setIsLoading(true);

    const result = await Swal.fire({
      title: "Create Account?",
      text: "Are you sure you want to create this account?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3b82f6",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Yes, create account!",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) {
      setIsLoading(false);
      return;
    }

    try {
      const submitData = {
        Usr_Name: formData.Usr_Name,
        Usr_Email: formData.Usr_Email,
        Usr_Mobile: formData.Usr_Mobile,
        Usr_Pas: formData.Usr_Pas,
        Usr_Pas_confirmation: formData.Usr_Pas_confirmation,
      };

      // Public endpoint - no auth token needed (new user is not logged in).
      const response = await axios.post(
        `${import.meta.env.VITE_API_URL}/register`,
        submitData
      );

      if (response.data.success) {
        Swal.fire({
          title: "Registration Successful!",
          html: `
            <div class="text-left">
              <p class="mb-3">Your account has been created successfully!</p>
              <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                <p class="text-sm text-blue-800"><strong>Username:</strong> ${formData.Usr_Name}</p>
                <p class="text-sm text-blue-800"><strong>Email:</strong> ${formData.Usr_Email}</p>
              </div>
              <p class="text-sm text-gray-600">You can now login with your credentials.</p>
            </div>
          `,
          icon: "success",
          confirmButtonColor: "#3b82f6",
          confirmButtonText: "Proceed to Login",
        }).then(() => {
          navigate("/login");
        });
      } else {
        toast.error(
          response.data.message || "Registration failed. Please try again.",
        );
      }
    } catch (error) {
      console.error("Error creating account:", error);

      if (error.response?.data?.errors) {
        const apiErrors = error.response.data.errors;
        const errorMessages = Object.values(apiErrors).flat().join(", ");
        toast.error(errorMessages);

        const fieldErrors = {};
        Object.keys(apiErrors).forEach((key) => {
          fieldErrors[key] = apiErrors[key][0];
        });
        setErrors(fieldErrors);
      } else if (error.response?.data?.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error("Failed to create account. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const steps = [
    { number: 1, title: "Account Information", icon: User },
    { number: 2, title: "Security Setup", icon: Lock },
    { number: 3, title: "Terms & Conditions", icon: Check },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50 flex items-center justify-center">
      <div className="w-full min-h-screen flex flex-col lg:flex-row shadow-xl overflow-hidden bg-white">
        {!isMobile && (
          <div className="lg:w-2/5 bg-gradient-to-br from-blue-600 to-blue-800 p-4 sm:p-6 md:p-8 lg:p-10 xl:p-12 flex flex-col justify-between relative overflow-hidden">
            <div className="absolute inset-0 opacity-5">
              <div className="absolute -top-16 -left-16 w-48 h-48 sm:w-64 sm:h-64 bg-white rounded-full"></div>
              <div className="absolute -bottom-24 -right-24 w-64 h-64 sm:w-96 sm:h-96 bg-white rounded-full"></div>
            </div>

            <div className="relative z-10">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-8 sm:mb-10 md:mb-12">
                <div className="flex items-center justify-center flex-shrink-0">
                  <img
                    src="C:\Users\Admin\Downloads\Ambaji-Project-updated\public\AMT_ambajimatatemple.png"
                    alt="Ambaji Logo"
                    className="h-20 w-70"
                  />
                </div>
              </div>

              <div className="space-y-4 sm:space-y-6">
                <h2 className="text-xl lg:text-2xl font-normal text-white leading-tight">
                  Join Ambaji Temple Portal
                </h2>
                <p className="text-blue-100 text-sm sm:text-base md:text-lg">
                  Register to access temple services, submit applications,
                  and manage your account
                </p>

                <div className="pt-4 sm:pt-6">
                  <div className="flex items-center justify-between mb-4">
                    {steps.map((stepItem) => (
                      <div
                        key={stepItem.number}
                        className="flex flex-col items-center"
                      >
                        <div
                          className={`h-10 w-10 rounded-full flex items-center justify-center mb-2 ${step >= stepItem.number
                            ? "bg-white text-blue-600"
                            : "bg-blue-700 text-blue-200"
                            }`}
                        >
                          {stepItem.number}
                        </div>
                        <span className="text-xs text-blue-100 text-center">
                          {stepItem.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 sm:space-y-3 pt-4 sm:pt-6">
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-blue-300 flex-shrink-0" />
                    <span className="text-blue-100 text-xs sm:text-sm">
                      Access all temple services online
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-blue-300 flex-shrink-0" />
                    <span className="text-blue-100 text-xs sm:text-sm">
                      Secure and encrypted data protection
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-blue-300 flex-shrink-0" />
                    <span className="text-blue-100 text-xs sm:text-sm">
                      Real-time application tracking
                    </span>
                  </div>
                </div>

                <div className="pt-4 sm:pt-6 border-t border-blue-700/30">
                  <div className="flex items-center space-x-3">
                    <User className="h-5 w-5 text-blue-300" />
                    <div>
                      <p className="text-blue-100 text-sm">
                        Already have an account?
                      </p>
                      <Link
                        to="/login"
                        className="text-blue-300 hover:text-blue-200 text-sm font-medium inline-flex items-center mt-1"
                      >
                        Sign in to your account
                        <ArrowRight className="ml-1 h-4 w-4" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-8 mb-0 pt-6 border-t border-blue-700/30">
              <p className="text-xs text-blue-300">
                © {new Date().getFullYear()} AARK InfoSoft Pvt. Ltd.
              </p>
              <p className="text-xs text-blue-400/70 mt-1">
                AMT Portal • Ambaji Temple
              </p>
            </div>
          </div>
        )}

        <div
          className={`${isMobile ? "w-full" : "lg:w-3/5"
            } p-4 sm:p-6 md:p-8 lg:p-10 xl:p-12`}
        >
          {isMobile && (
            <div className="mb-6 sm:mb-8">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <div className="h-12 w-12 bg-gradient-to-r from-blue-600 to-blue-800 rounded-xl flex items-center justify-center">
                  <Building className="h-7 w-7 text-white" />
                </div>
                <div className="text-center">
                  <h1 className="text-xl font-bold text-gray-900">
                    AMT Portal
                  </h1>
                  <p className="text-gray-600 text-sm">
                    Ambaji Temple
                  </p>
                </div>
              </div>

              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  {steps.map((stepItem) => (
                    <div
                      key={stepItem.number}
                      className="flex flex-col items-center"
                    >
                      <div
                        className={`h-8 w-8 rounded-full flex items-center justify-center mb-1 ${step >= stepItem.number
                          ? "bg-blue-600 text-white"
                          : "bg-gray-200 text-gray-600"
                          }`}
                      >
                        {stepItem.number}
                      </div>
                      <span className="text-xs text-gray-600">
                        {stepItem.title}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className={`${isMobile ? "" : "max-w-md mx-auto"}`}>
            {!isMobile && (
              <div className="text-center mb-6 sm:mb-8 md:mb-10">
                <div className="inline-flex items-center justify-center h-12 w-12 sm:h-14 sm:w-14 md:h-16 md:w-16 rounded-xl sm:rounded-2xl bg-gradient-to-r from-blue-500 to-blue-600 mb-4 sm:mb-6">
                  <UserPlus className="h-5 w-5 sm:h-6 sm:w-6 md:h-7 md:w-7 text-white" />
                </div>
                <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-2 sm:mb-3">
                  Create Account
                </h2>
                <p className="text-gray-600 text-xs sm:text-sm md:text-base">
                  Step {step} of 3: {steps[step - 1]?.title}
                </p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              {step == 1 && (
                <>
                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1.5 sm:mb-2">
                      Username *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        name="Usr_Name"
                        value={formData.Usr_Name}
                        onChange={handleInputChange}
                        className={`pl-9 sm:pl-10 pr-3 sm:pr-4 block w-full py-2.5 sm:py-3 md:py-3.5 border ${errors.Usr_Name ? "border-red-300" : "border-gray-300"
                          } rounded-lg sm:rounded-xl shadow-sm focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base`}
                        placeholder="Enter username"
                        maxLength={50}
                        autoComplete="off"
                      />
                    </div>
                    {errors.Usr_Name && (
                      <p className="mt-1 text-xs text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.Usr_Name}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Unique username for login (max 50 characters)
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1.5 sm:mb-2">
                      Email Address *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Mail className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                      <input
                        type="email"
                        name="Usr_Email"
                        value={formData.Usr_Email}
                        onChange={handleInputChange}
                        className={`pl-9 sm:pl-10 pr-3 sm:pr-4 block w-full py-2.5 sm:py-3 md:py-3.5 border ${errors.Usr_Email
                          ? "border-red-300"
                          : "border-gray-300"
                          } rounded-lg sm:rounded-xl shadow-sm focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base`}
                        placeholder="Enter email address"
                        maxLength={100}
                        autoComplete="off"
                      />
                    </div>
                    {errors.Usr_Email && (
                      <p className="mt-1 text-xs text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.Usr_Email}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Your email address (max 100 characters)
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1.5 sm:mb-2">
                      Mobile Number *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                      <input
                        type="tel"
                        name="Usr_Mobile"
                        value={formData.Usr_Mobile}
                        onChange={handleInputChange}
                        className={`pl-9 sm:pl-10 pr-3 sm:pr-4 block w-full py-2.5 sm:py-3 md:py-3.5 border ${errors.Usr_Mobile
                          ? "border-red-300"
                          : "border-gray-300"
                          } rounded-lg sm:rounded-xl shadow-sm focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base`}
                        placeholder="+911234567890"
                        maxLength={15}
                        autoComplete="off"
                      />
                    </div>
                    {errors.Usr_Mobile && (
                      <p className="mt-1 text-xs text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.Usr_Mobile}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Your mobile number with country code
                    </p>
                  </div>

                </>
              )}

              {step == 2 && (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">
                      Password Settings
                    </h3>
                    <button
                      type="button"
                      onClick={generatePassword}
                      className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm font-medium flex items-center"
                    >
                      <Key className="h-4 w-4 mr-2" />
                      Generate Password
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1.5 sm:mb-2">
                      Password *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                      <input
                        type={showPassword ? "text" : "password"}
                        name="Usr_Pas"
                        value={formData.Usr_Pas}
                        onChange={handleInputChange}
                        className={`pl-9 sm:pl-10 pr-10 block w-full py-2.5 sm:py-3 md:py-3.5 border ${errors.Usr_Pas ? "border-red-300" : "border-gray-300"
                          } rounded-lg sm:rounded-xl shadow-sm focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base`}
                        placeholder="Enter password"
                        minLength={8}
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400 hover:text-gray-600" />
                        ) : (
                          <Eye className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400 hover:text-gray-600" />
                        )}
                      </button>
                    </div>
                    {errors.Usr_Pas && (
                      <p className="mt-1 text-xs text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.Usr_Pas}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Minimum 8 characters with letters, numbers, and special
                      characters
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs sm:text-sm font-medium text-gray-700 mb-1.5 sm:mb-2">
                      Confirm Password *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Lock className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400" />
                      </div>
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        name="Usr_Pas_confirmation"
                        value={formData.Usr_Pas_confirmation}
                        onChange={handleInputChange}
                        className={`pl-9 sm:pl-10 pr-10 block w-full py-2.5 sm:py-3 md:py-3.5 border ${errors.Usr_Pas_confirmation
                          ? "border-red-300"
                          : "border-gray-300"
                          } rounded-lg sm:rounded-xl shadow-sm focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all text-sm sm:text-base`}
                        placeholder="Confirm password"
                        minLength={8}
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400 hover:text-gray-600" />
                        ) : (
                          <Eye className="h-4 w-4 sm:h-5 sm:w-5 text-gray-400 hover:text-gray-600" />
                        )}
                      </button>
                    </div>
                    {errors.Usr_Pas_confirmation && (
                      <p className="mt-1 text-xs text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.Usr_Pas_confirmation}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Re-enter the password for confirmation
                    </p>
                  </div>
                </>
              )}

              {step == 3 && (
                <>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg sm:rounded-xl p-4 sm:p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">
                      Terms & Conditions
                    </h3>
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-900">
                          1. Account Usage
                        </h4>
                        <p className="text-xs text-gray-600">
                          • You are responsible for maintaining the
                          confidentiality of your account and password
                        </p>
                        <p className="text-xs text-gray-600">
                          • You agree to notify us immediately of any
                          unauthorized use of your account
                        </p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-900">
                          2. Data Privacy
                        </h4>
                        <p className="text-xs text-gray-600">
                          • We collect and process your data in accordance with
                          our Privacy Policy
                        </p>
                        <p className="text-xs text-gray-600">
                          • Your personal information is protected and encrypted
                        </p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-900">
                          3. Service Usage
                        </h4>
                        <p className="text-xs text-gray-600">
                          • You agree to use the portal only for lawful purposes
                        </p>
                        <p className="text-xs text-gray-600">
                          • Misuse of the system may result in account
                          termination
                        </p>
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-sm font-medium text-gray-900">
                          4. Device Registration
                        </h4>
                        <p className="text-xs text-gray-600">
                          • First login requires device approval for security
                          purposes
                        </p>
                        <p className="text-xs text-gray-600">
                          • Unauthorized device access will be blocked
                        </p>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`p-4 rounded-lg sm:rounded-xl border ${errors.terms
                      ? "border-red-300 bg-red-50"
                      : "border-gray-300 bg-gray-50"
                      }`}
                  >
                    <div className="flex items-start">
                      <input
                        id="accept-terms"
                        name="accept-terms"
                        type="checkbox"
                        checked={acceptTerms}
                        onChange={(e) => setAcceptTerms(e.target.checked)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mt-0.5"
                      />
                      <label
                        htmlFor="accept-terms"
                        className="ml-3 block text-sm text-gray-700"
                      >
                        I have read and agree to the Terms & Conditions and
                        Privacy Policy
                      </label>
                    </div>
                    {errors.terms && (
                      <p className="mt-2 text-sm text-red-600 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        {errors.terms}
                      </p>
                    )}
                  </div>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg sm:rounded-xl p-4">
                    <div className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-yellow-800 mb-1">
                          Important Notice
                        </p>
                        <p className="text-xs text-yellow-700">
                          After registration, your account will require device
                          approval on first login. Please ensure you're using a
                          trusted device.
                        </p>
                      </div>
                    </div>
                  </div>
                </>
              )}

              <div className="flex space-x-3 sm:space-x-4 pt-4">
                {step > 1 && (
                  <button
                    type="button"
                    onClick={handlePreviousStep}
                    className="flex-1 flex justify-center items-center py-3 sm:py-4 px-4 border border-gray-300 rounded-lg sm:rounded-xl shadow-sm text-sm sm:text-base font-semibold text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-offset-1 sm:focus:ring-offset-2 focus:ring-gray-500 transition-all"
                  >
                    <ArrowLeft className="mr-1.5 sm:mr-2 h-4 w-4 sm:h-5 sm:w-5" />
                    Back
                  </button>
                )}

                {step < 3 ? (
                  <button
                    type="button"
                    onClick={handleNextStep}
                    className="flex-1 flex justify-center items-center py-3 sm:py-4 px-4 border border-transparent rounded-lg sm:rounded-xl shadow-sm text-sm sm:text-base font-semibold text-white bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-offset-1 sm:focus:ring-offset-2 focus:ring-blue-500 transition-all hover:shadow-md sm:hover:shadow-lg"
                  >
                    Next Step
                    <ArrowRight className="ml-1.5 sm:ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={isLoading}
                    className={`flex-1 flex justify-center items-center py-3 sm:py-4 px-4 border border-transparent rounded-lg sm:rounded-xl shadow-sm text-sm sm:text-base font-semibold text-white bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 focus:outline-none focus:ring-1 sm:focus:ring-2 focus:ring-offset-1 sm:focus:ring-offset-2 focus:ring-blue-500 transition-all ${isLoading
                      ? "opacity-75 cursor-not-allowed"
                      : "hover:shadow-md sm:hover:shadow-lg"
                      }`}
                  >
                    {isLoading ? (
                      <>
                        <svg
                          className="animate-spin -ml-1 mr-2 sm:mr-3 h-4 w-4 sm:h-5 sm:w-5 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                        Creating Account...
                      </>
                    ) : (
                      "Create Account"
                    )}
                  </button>
                )}
              </div>

              {isMobile && (
                <div className="text-center pt-4 sm:pt-6">
                  <p className="text-sm text-gray-600">
                    Already have an account?{" "}
                    <Link
                      to="/login"
                      className="font-medium text-blue-600 hover:text-blue-700"
                    >
                      Sign in here
                    </Link>
                  </p>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Registration;