import { useState, useEffect, useMemo } from "react";
import { toast } from "react-hot-toast";
import axios from "axios";
import {
  Plus,
  Edit,
  Trash2,
  Search,
  Loader2,
  X,
  Check,
  Package,
  IndianRupee,
  Clock,
  Users,
  Calendar,
} from "lucide-react";

const localDate = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};

/**
 * Time slots - koi bhi time MANUALLY type kar sakte hain (fixed 30-min
 * dropdown nahi).
 *
 * Accept:  "7:30"  "07:30"  "7:30 AM"  "7:30 pm"  "19:30"  "7"  "7 pm"
 * Return:  "HH:MM" (24-hour) ya invalid ho to null
 */
const parseTimeInput = (raw) => {
  const s = String(raw || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "");
  if (!s) return null;

  const meridiem =
    s.endsWith("AM") || s.endsWith("PM") ? s.slice(-2) : null;
  const body = meridiem ? s.slice(0, -2) : s;

  const m = body.match(/^(\d{1,2})(?::(\d{1,2}))?$/);
  if (!m) return null;

  let hh = parseInt(m[1], 10);
  const mm = m[2] !== undefined ? parseInt(m[2], 10) : 0;
  if (mm > 59) return null;

  if (meridiem === "AM") {
    if (hh < 1 || hh > 12) return null;
    if (hh === 12) hh = 0;
  } else if (meridiem === "PM") {
    if (hh < 1 || hh > 12) return null;
    if (hh !== 12) hh += 12;
  } else if (hh > 23) {
    return null;
  }

  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
};

/** "07:30" -> "07:30 AM" (display ke liye) */
const to12Hour = (hhmm) => {
  if (!hhmm) return "";
  const [h, m] = String(hhmm).split(":").map(Number);
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${String(hh).padStart(2, "0")}:${String(m).padStart(2, "0")} ${
    h < 12 ? "AM" : "PM"
  }`;
};

const SevaPackages = ({ user }) => {
  const [rows, setRows] = useState([]);
  const [services, setServices] = useState([]);
  const [kinds, setKinds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [query, setQuery] = useState("");
  const [svcFilter, setSvcFilter] = useState("");
  const [kindFilter, setKindFilter] = useState("");

  const [form, setForm] = useState({
    service_id: "",
    service_kind: "",
    name: "",
    description: "",
    includes: [],
    fee: "",
    duration_minutes: "",
    daily_quota: "",
    person_limit: "",
    max_persons: 1,
    slot_times: [],
    custom_fields: [],
    effective_from: "",
    effective_to: "",
    sort_order: 0,
    is_active: true,
  });

  const [includeInput, setIncludeInput] = useState("");
  const [slotError, setSlotError] = useState(false);
  const [slotDraft, setSlotDraft] = useState({
    start: "",
    end: "",
    label: "",
    capacity: "",
  });

  const token = localStorage.getItem("auth_token");
  const base = import.meta.env.VITE_API_URL;
  const headers = { Authorization: `Bearer ${token}` };

  const fetchAll = async () => {
    try {
      setLoading(true);
      const [svcRes, pkgRes, kindRes] = await Promise.all([
        axios.get(`${base}/seva/services?per_page=200`, { headers }),
        axios.get(`${base}/seva/packages?per_page=200`, { headers }),
        axios.get(`${base}/seva/kinds`, { headers }),
      ]);
      if (svcRes.data?.success) {
        setServices(svcRes.data.data?.data || svcRes.data.data || []);
      }
      if (kindRes.data?.success) {
        setKinds(kindRes.data.data?.data || kindRes.data.data || []);
      }
      if (pkgRes.data?.success) {
        const list = pkgRes.data.data?.data || pkgRes.data.data || [];
        setRows(
          list.map((p) => ({
            ...p,
            service_name: p.service?.name || "",
            service_code: p.service?.code || "",
          }))
        );
      }
    } catch (e) {
      toast.error(e.response?.data?.message || "Failed to load packages");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const filtered = useMemo(
    () =>
      rows.filter((r) => {
        const bySvc = !svcFilter || r.service_id == svcFilter;
        const byKind = !kindFilter || r.service_kind == kindFilter;
        const byText = `${r.name} ${r.code || ""} ${r.service_name || ""} ${
          r.description || ""
        }`
          .toLowerCase()
          .includes(query.trim().toLowerCase());
        return bySvc && byKind && byText;
      }),
    [rows, query, svcFilter, kindFilter]
  );

  // Service Type code ka naam (POOJA -> Pooja)
  const kindLabel = (code) =>
    kinds.find((k) => k.code === code)?.name || code || "—";

  // Service Type ke hisaab se Services filter (current service hamesha dikhe)
  const visibleServices = useMemo(() => {
    const kind = form.service_kind;
    if (!kind) return services;
    return services.filter(
      (s) => s.service_kind === kind || s.service_id == form.service_id
    );
  }, [services, form.service_kind, form.service_id]);

  const selectedService = services.find((s) => String(s.service_id) === String(form.service_id));
  const isTithiBhojanPackage = selectedService?.service_mode === "TITHI_BHOJAN";

  const openCreate = () => {
    setEditing(null);
    setForm({
      service_id: services[0]?.service_id || "",
      service_kind:
        services.find((s) => s.service_id == services[0]?.service_id)
          ?.service_kind || "",
      name: "",
      description: "",
      includes: [],
      fee: "",
      duration_minutes: "",
      daily_quota: "",
      max_persons: 1,
      slot_times: [],
      custom_fields: [],
      effective_from: "",
      effective_to: "",
      sort_order: rows.length + 1,
      is_active: true,
    });
    setIncludeInput("");
    setSlotDraft({ start: "", end: "", label: "", capacity: "" });
    setSlotError(false);
    setShowForm(true);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      service_id: p.service_id,
      service_kind:
        p.service_kind ||
        services.find((s) => s.service_id == p.service_id)?.service_kind ||
        "",
      name: p.name || "",
      description: p.description || "",
      includes: Array.isArray(p.included_list)
        ? p.included_list
        : Array.isArray(p.includes)
          ? p.includes
          : [],
      fee: p.fee ?? "",
      duration_minutes: p.duration_minutes ?? "",
      daily_quota: p.daily_quota ?? "",
      person_limit: p.person_limit ?? "",
      max_persons: p.persons_per_booking ?? p.max_persons ?? 1,
      slot_times: Array.isArray(p.slot_times)
        ? p.slot_times.map((t) => ({
            start: t.start,
            end: t.end,
            label: t.label || "",
            capacity: t.capacity ?? 0,
          }))
        : [],
      custom_fields: Array.isArray(p.custom_fields) ? p.custom_fields : [],
      effective_from: p.effective_from || "",
      effective_to: p.effective_to || "",
      sort_order: p.sort_order ?? 0,
      is_active: !!p.is_active,
    });
    setIncludeInput("");
    setSlotDraft({ start: "", end: "", label: "", capacity: "" });
    setSlotError(false);
    setShowForm(true);
  };

  // ---------- What's included : bullet chips ----------
  const addInclude = () => {
    const val = includeInput.trim();
    if (!val) return;
    if (form.includes.includes(val)) {
      setIncludeInput("");
      return;
    }
    setForm((p) => ({ ...p, includes: [...p.includes, val] }));
    setIncludeInput("");
  };

  const removeInclude = (item) =>
    setForm((p) => ({
      ...p,
      includes: p.includes.filter((i) => i !== item),
    }));

  // ---------- Custom fields (admin can add any field with name + type) ----------
  const addCustomField = () => {
    setForm((p) => ({
      ...p,
      custom_fields: [
        ...p.custom_fields,
        { field_name: "", field_type: "text", field_value: "" },
      ],
    }));
  };

  const updateCustomField = (idx, key, value) => {
    setForm((p) => {
      const next = [...p.custom_fields];
      next[idx] = { ...next[idx], [key]: value };
      return { ...p, custom_fields: next };
    });
  };

  const removeCustomField = (idx) => {
    setForm((p) => ({
      ...p,
      custom_fields: p.custom_fields.filter((_, i) => i !== idx),
    }));
  };

  // ---------- Time slots (multiple, dynamic/recurring) ----------
  const addEndTime = (start, mins) => {
    const [h, m] = String(start).split(":").map(Number);
    const total = h * 60 + m + (mins || 60);
    const hh = Math.floor(total / 60) % 24;
    const mm = total % 60;
    return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  };

  const addSlot = () => {
    const dur = Number(form.duration_minutes) || 60;

    // User ne manually time type kiya hai - parse karo
    let start = parseTimeInput(slotDraft.start);
    const endInput = parseTimeInput(slotDraft.end);

    // Sirf END diya ho to START apne aap nikalo (End - duration)
    if (!start && endInput) {
      const [eh, em] = endInput.split(":").map(Number);
      let total = eh * 60 + em - dur;
      if (total < 0) total += 24 * 60;
      start = `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(
        total % 60
      ).padStart(2, "0")}`;
    }

    if (!start) {
      setSlotError(true);
      toast.error(
        slotDraft.start
          ? "Enter a valid START time (e.g. 07:30 AM)"
          : "Please enter the slot START time"
      );
      return;
    }

    if (slotDraft.end && !endInput) {
      toast.error("Enter a valid END time (e.g. 08:30 AM)");
      return;
    }

    setSlotError(false);

    let end = endInput;
    if (!end) {
      end = addEndTime(start, dur);
    }
    // End <= Start ho to raat cross midnight hai (e.g. 11:00 PM - 12:30 AM)
    // - clock time as it is store hota hai.

    setForm((p) => ({
      ...p,
      slot_times: [
        ...p.slot_times,
        {
          start,
          end,
          label: slotDraft.label || "",
          capacity: Number(slotDraft.capacity) || 0,
        },
      ],
    }));

    setSlotDraft({ start: "", end: "", label: "", capacity: "" });
    setSlotError(false);
  };

  // End input ka "Auto" hint - duration hisaab se
  const autoEndLabel = useMemo(() => {
    const parsed = parseTimeInput(slotDraft.start);
    if (!parsed) return "based on duration";

    const dur = Number(form.duration_minutes) || 60;
    return to12Hour(addEndTime(parsed, dur));
  }, [slotDraft.start, form.duration_minutes]);

  const removeSlot = (idx) =>    setForm((p) => ({
      ...p,
      slot_times: p.slot_times.filter((_, i) => i !== idx),
    }));

  const handleSave = async () => {
    if (!form.service_id) return toast.error("Select a service");
    if (!form.service_kind) return toast.error("Select a service type");
    if (!form.name.trim()) return toast.error("Package name is required");
    if (form.fee === "" || Number(form.fee) < 0)
      return toast.error("Base fee is required");
    if (isTithiBhojanPackage && !form.effective_from)
      return toast.error("Start date is required for Tithi Bhojan packages");
    if (isTithiBhojanPackage && !form.effective_to)
      return toast.error("End date is required for Tithi Bhojan packages");
    if (isTithiBhojanPackage && form.slot_times.length === 0)
      return toast.error("Add at least one meal slot for Tithi Bhojan");
    if (form.effective_from && form.effective_to && form.effective_to < form.effective_from)
      return toast.error("End date cannot be before start date");

    try {
      setSaving(true);
      const payload = { ...form };
      Object.keys(payload).forEach((k) => {
        if (payload[k] === "" || payload[k] === null) delete payload[k];
      });
      payload.name = form.name.trim();
      payload.includes = form.includes;
      payload.custom_fields = form.custom_fields.filter(
        (f) => f.field_name && f.field_name.trim()
      );
      payload.max_persons = Number(form.max_persons) || 1;
      payload.slot_times = form.slot_times;
      payload.sort_order = form.sort_order || 0;

      // Daily limit HAMESHA bhejo (0 = unlimited). Agar ye delete ho gaya to
      // dusre package me purana limit reh jayega aur portal par old value dikhega.
      payload.daily_quota = Number(form.daily_quota) || 0;
      // Total booking limit (persons) - 0 = unlimited. Consumed as payments succeed.
      payload.person_limit = Number(form.person_limit) || 0;

      if (editing) {
        await axios.put(
          `${base}/seva/packages/${editing.package_id}`,
          payload,
          { headers }
        );
        toast.success("Package updated");
      } else {
        await axios.post(`${base}/seva/packages`, payload, { headers });
        toast.success("Package created");
      }
      setShowForm(false);
      fetchAll();
    } catch (e) {
      const errs = e.response?.data?.errors
        ? Object.values(e.response.data.errors).flat().join(", ")
        : e.response?.data?.message;
      toast.error(errs || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (p) => {
    if (!window.confirm(`Delete package "${p.name}"?`)) return;
    try {
      await axios.delete(`${base}/seva/packages/${p.package_id}`, { headers });
      toast.success("Package deleted");
      fetchAll();
    } catch (e) {
      toast.error(e.response?.data?.message || "Delete failed (may be in use)");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-red-600" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Seva Packages</h1>
          <p className="text-sm text-gray-500">
            Base fee, duration, daily quota and persons limits live here and
            connect to services
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search packages"
              className="w-56 rounded-lg border border-gray-300 py-2 pl-9 pr-3 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
            />
          </div>
          <select
            value={svcFilter}
            onChange={(e) => setSvcFilter(e.target.value)}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">All Services</option>
            {services.map((s) => (
              <option key={s.service_id} value={s.service_id}>
                {s.name}
              </option>
            ))}
          </select>
          <select
            value={kindFilter}
            onChange={(e) => setKindFilter(e.target.value)}
            className="rounded-lg border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">All Service Types</option>
            {kinds.map((k) => (
              <option key={k.kind_id ?? k.code} value={k.code}>
                {k.name}
              </option>
            ))}
          </select>
          <button
            onClick={openCreate}
            className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
          >
            <Plus className="h-4 w-4" /> Add Package
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          ["Total Packages", rows.length, "text-gray-900"],
          [
            "Active",
            rows.filter((r) => r.is_active).length,
            "text-emerald-600",
          ],
          [
            "Services Covered",
            new Set(rows.map((r) => r.service_id)).size,
            "text-blue-600",
          ],
          [
            "Avg Fee",
            "Rs. " +
              (
                rows.length
                  ? rows.reduce(
                      (a, r) => a + Number(r.fee || 0),
                      0
                    ) / rows.length
                  : 0
              ).toFixed(0),
            "text-amber-600",
          ],
        ].map(([label, value, color]) => (
          <div
            key={label}
            className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm"
          >
            <p className="text-xs text-gray-500">{label}</p>
            <p className={`mt-1 text-2xl font-bold ${color}`}>{value}</p>
          </div>
        ))}
      </div>

      <div className="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                {[
                  "#",
                  "Package",
                  "Service",
                  "Service Type",
                  "Base Fee",
                  "Pooja Duration",
                  "Daily Limit",
                  "Per Group / Limit",
                  "Custom Fields",
                  "Start - End Date",
                  "Status",
                  "Actions",
                ].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((r, idx) => (
                <tr key={r.package_id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm text-gray-500">{idx + 1}</td>
                  <td className="px-4 py-3">
                    <p className="text-sm font-semibold text-gray-900">
                      {r.name}
                    </p>
                    {r.description && (
                      <p className="max-w-[14rem] truncate text-[11px] text-gray-500">
                        {r.description}
                      </p>
                    )}
                    {(r.included_list || []).length > 0 && (
                      <ul className="mt-1 space-y-0.5">
                        {(r.included_list || []).slice(0, 3).map((inc, i) => (
                          <li
                            key={i}
                            className="flex items-start gap-1 text-[11px] text-gray-500"
                          >
                            <span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-red-400" />
                            <span className="truncate">{inc}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">
                    {r.service_name || "—"}
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <span className="inline-flex rounded-full bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-700">
                      {kindLabel(r.service_kind)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm font-semibold text-gray-900">
                    Rs. {Number(r.fee || 0).toFixed(2)}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">
                    {r.duration_minutes ? `${r.duration_minutes} min` : "—"}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">
                    {r.daily_quota ? `${r.daily_quota} persons` : "Unlimited"}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">
                    {r.service?.service_mode === "TITHI_BHOJAN" ? (
                      (r.slot_times || []).length ? (
                        <div className="space-y-0.5">
                          {(r.slot_times || []).map((t, i) => (
                            <p key={i} className="text-[11px] text-gray-700">
                              {t.label || `${t.start} - ${t.end}`}:{" "}
                              <span className="font-medium text-gray-900">
                                {Number(t.capacity) > 0 ? `${t.capacity} persons` : "Unlimited"}
                              </span>
                            </p>
                          ))}
                        </div>
                      ) : (
                        <span className="text-gray-400">No slots</span>
                      )
                    ) : (
                      <p className="font-medium text-gray-800">
                        {r.persons_per_booking ?? r.max_persons ?? 1} per group
                      </p>
                    )}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">
                    {(r.custom_fields || []).length > 0 ? (
                      <div className="space-y-0.5">
                        {(r.custom_fields || []).map((f, i) => (
                          <p
                            key={i}
                            className="flex items-start gap-1 text-[11px] text-amber-800"
                          >
                            <span className="mt-0.5 h-1 w-1 shrink-0 rounded-full bg-amber-500" />
                            <span className="font-semibold">{f.field_name}:</span>{" "}
                            <span>{f.field_value || "—"}</span>
                          </p>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-400">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-gray-600">
                    {r.effective_from || r.effective_to ? (
                      <>
                        <p className="font-medium text-gray-800">
                          {r.effective_from || "Open"}
                        </p>
                        <p className="text-gray-500">to {r.effective_to || "Open"}</p>
                      </>
                    ) : (
                      <span className="text-gray-400">
                        {r.service?.service_mode === "TITHI_BHOJAN" ? "Dates not set" : "Always"}
                      </span>
                    )}
                    {r.service?.service_mode === "TITHI_BHOJAN" && (!r.effective_from || !r.effective_to || !r.slot_times?.length) && (
                      <p className="mt-1 font-semibold text-amber-700">Needs dates and meal slots</p>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                        !r.is_active || (r.effective_to && r.effective_to < localDate())
                          ? "bg-gray-200 text-gray-600"
                          : r.service?.service_mode === "TITHI_BHOJAN" && (!r.effective_from || !r.effective_to || !r.slot_times?.length)
                            ? "bg-amber-100 text-amber-800"
                            : "bg-emerald-100 text-emerald-700"
                      }`}
                    >
                      {!r.is_active ? "Inactive" : r.effective_to && r.effective_to < localDate() ? "Expired" : r.service?.service_mode === "TITHI_BHOJAN" && (!r.effective_from || !r.effective_to || !r.slot_times?.length) ? "Needs setup" : "Active"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEdit(r)}
                        className="rounded-lg border border-gray-300 px-2.5 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                        title="Edit"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(r)}
                        className="rounded-lg border border-red-300 px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50"
                        title="Delete"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td
                    colSpan={11}
                    className="px-4 py-12 text-center text-sm text-gray-500"
                  >
                    No packages found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-gray-200 px-5 py-4">
              <h3 className="text-base font-semibold text-gray-900">
                {editing ? "Edit Package" : "Add Package"}
              </h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-4 px-5 py-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-700">
                    Service *
                  </label>
                  <select
                    value={form.service_id}
                    onChange={(e) => {
                      const svcId = e.target.value;
                      const svc = services.find((s) => s.service_id == svcId);

                      // Service Type apne aap service ke type se sync ho jata hai
                      setForm((p) => ({
                        ...p,
                        service_id: svcId,
                        service_kind: svc?.service_kind || p.service_kind,
                      }));
                    }}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  >
                    <option value="">— select —</option>
                    {visibleServices.length === 0 && (
                      <option value="" disabled>
                        No service of this type
                      </option>
                    )}
                    {visibleServices.map((s) => (
                      <option key={s.service_id} value={s.service_id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-700">
                    Service Type *
                  </label>
                  <select
                    value={form.service_kind}
                    onChange={(e) => {
                      const kind = e.target.value;
                      const cur = services.find(
                        (s) => s.service_id == form.service_id
                      );

                      // Type change kiya to service match na kare to clear
                      setForm((p) => ({
                        ...p,
                        service_kind: kind,
                        service_id:
                          cur && cur.service_kind === kind
                            ? p.service_id
                            : kind
                            ? ""
                            : p.service_id,
                      }));
                    }}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  >
                    <option value="">— select —</option>
                    {kinds.map((k) => (
                      <option key={k.kind_id ?? k.code} value={k.code}>
                        {k.name} ({k.code})
                      </option>
                    ))}
                  </select>
                  <p className="mt-1 text-[10px] text-gray-500">
                    Service select karne par type apne aap set ho jata hai. Type
                    select karne par sirf usi type ke services dikhenge.
                  </p>
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-700">
                    Package Name *
                  </label>
                  <input
                    value={form.name}
                    onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                    placeholder="Basic (1 person)"
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-700">
                    Base Fee (Rs) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={form.fee}
                    onChange={(e) => setForm((p) => ({ ...p, fee: e.target.value }))}
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                </div>

                {!isTithiBhojanPackage && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-700">
                      Pooja Duration
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={form.duration_minutes}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, duration_minutes: e.target.value }))
                      }
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                    />
                  </div>
                )}

                {!isTithiBhojanPackage && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-700">
                      Daily Limit (persons / day for this seva)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={form.daily_quota}
                      onChange={(e) =>
                        setForm((p) => ({ ...p, daily_quota: e.target.value }))
                      }
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                    />
                    <p className="mt-1 text-[10px] text-gray-500">
                      Tithi Bhojan के लिए दैनिक सीमा लागू नहीं होती।
                    </p>
                  </div>
                )}

                {!isTithiBhojanPackage && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-700">
                      Persons per Group
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={form.max_persons}
                      onChange={(e) =>
                        setForm((p) => ({
                          ...p,
                          max_persons: e.target.value,
                        }))
                      }
                      className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                    />
                    <p className="mt-1 text-[10px] text-gray-500">
                      Group size - कितने persons एक booking में आ सकते हैं।
                    </p>
                  </div>
                )}

                <div>
                    <label className="mb-1 block text-xs font-medium text-gray-700">
                    Start Date {isTithiBhojanPackage && "*"}
                  </label>
                  <input
                    type="date"
                    required={isTithiBhojanPackage}
                    value={form.effective_from}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, effective_from: e.target.value }))
                    }
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-700">
                    End Date {isTithiBhojanPackage && "*"}
                  </label>
                  <input
                    type="date"
                    required={isTithiBhojanPackage}
                    min={form.effective_from || undefined}
                    value={form.effective_to}
                    onChange={(e) =>
                      setForm((p) => ({ ...p, effective_to: e.target.value }))
                    }
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                  {isTithiBhojanPackage && <p className="mt-1 text-[10px] text-amber-700">Bookings close automatically after this end date. Add at least one meal slot below.</p>}
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={form.description}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, description: e.target.value }))
                  }
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-gray-700">
                  What's included
                </label>
                <div className="flex gap-2">
                  <input
                    value={includeInput}
                    onChange={(e) => setIncludeInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addInclude();
                      }
                    }}
                    placeholder="Type an item and press Enter"
                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
                  />
                  <button
                    type="button"
                    onClick={addInclude}
                    className="shrink-0 rounded-lg border border-gray-300 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                  >
                    Add
                  </button>
                </div>
                {form.includes.length > 0 && (
                  <ul className="mt-2 space-y-1.5">
                    {form.includes.map((item, i) => (
                      <li
                        key={i}
                        className="flex items-center gap-2 rounded-lg bg-gray-50 px-2.5 py-1.5 text-xs text-gray-700"
                      >
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-red-500" />
                        <span className="flex-1">{item}</span>
                        <button
                          type="button"
                          onClick={() => removeInclude(item)}
                          className="text-gray-400 hover:text-red-600"
                          title="Remove"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              {/* Custom Fields - admin can add any field */}
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
                <div className="mb-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                      <Plus className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-amber-800">
                        Custom Fields (Dynamic)
                      </p>
                      <p className="text-[10px] text-amber-600">
                        Add service-specific fields (e.g. Pandit name, Prashad
                        type, Yagna material, Gotra required...)
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={addCustomField}
                    className="shrink-0 rounded-lg border border-amber-300 px-3 py-2 text-xs font-medium text-amber-700 hover:bg-amber-100 transition"
                  >
                    <Plus className="h-3 w-3" /> Add Field
                  </button>
                </div>

                <div className="space-y-2">
                  {form.custom_fields.map((field, idx) => (
                    <div
                      key={idx}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-2 rounded-lg bg-white p-2.5 border border-amber-200"
                    >
                      <div className="sm:col-span-5">
                        <label className="mb-1 block text-[10px] font-medium text-amber-700">
                          Field Name
                        </label>
                        <input
                          value={field.field_name}
                          onChange={(e) =>
                            updateCustomField(idx, "field_name", e.target.value)
                          }
                          placeholder="e.g. Pandit Name"
                          className="w-full rounded border border-gray-300 bg-white px-2 py-1.5 text-xs focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                      <div className="sm:col-span-3">
                        <label className="mb-1 block text-[10px] font-medium text-amber-700">
                          Field Type
                        </label>
                        <select
                          value={field.field_type}
                          onChange={(e) =>
                            updateCustomField(idx, "field_type", e.target.value)
                          }
                          className="w-full rounded border border-gray-300 bg-white px-2 py-1.5 text-xs focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        >
                          <option value="text">Text</option>
                          <option value="number">Number</option>
                          <option value="date">Date</option>
                          <option value="select">Select/Dropdown</option>
                          <option value="checkbox">Checkbox</option>
                          <option value="textarea">Text Area</option>
                        </select>
                      </div>
                      <div className="sm:col-span-3">
                        <label className="mb-1 block text-[10px] font-medium text-amber-700">
                          Default Value
                        </label>
                        <input
                          value={field.field_value}
                          onChange={(e) =>
                            updateCustomField(idx, "field_value", e.target.value)
                          }
                          placeholder="Default value"
                          className="w-full rounded border border-gray-300 bg-white px-2 py-1.5 text-xs focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                      <div className="flex items-end sm:col-span-1">
                        <button
                          type="button"
                          onClick={() => removeCustomField(idx)}
                          className="rounded border border-red-300 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                  {form.custom_fields.length === 0 && (
                    <p className="mt-2 text-[10px] text-amber-500 italic">
                      No custom fields yet. Click "Add Field" to create
                      service-specific fields.
                    </p>
                  )}
                </div>
              </div>

              {/* TIME SLOTS - dynamic (recurring) */}
              <div className="rounded-xl border border-gray-200 bg-gray-50/60 p-3">
                <div className="mb-3 flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-red-50 text-red-600">
                      <Clock className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-gray-800">
                        Time Slots {isTithiBhojanPackage && <span className="text-red-600">*</span>}
                      </p>
                      <p className="text-[10px] text-gray-500">
                        Har din repeat hote hain - koi bhi time manually type
                        karein (7:30 AM, 19:45, 05:15...)
                      </p>
                    </div>
                  </div>
                  {form.slot_times.length > 0 && (
                    <span className="shrink-0 rounded-full bg-white px-2.5 py-1 text-[10px] font-medium text-gray-600 ring-1 ring-gray-200">
                      {form.slot_times.length} slot
                      {form.slot_times.length > 1 ? "s" : ""} added
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-12">
                  <div className="sm:col-span-3">
                    <label className="mb-1 block text-[10px] font-medium text-gray-500">
                      Start time <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={slotDraft.start}
                      onChange={(e) =>
                        setSlotDraft((s) => ({ ...s, start: e.target.value }))
                      }
                      onBlur={() => {
                        const parsed = parseTimeInput(slotDraft.start);
                        if (parsed && parsed !== slotDraft.start) {
                          setSlotDraft((s) => ({
                            ...s,
                            start: to12Hour(parsed),
                          }));
                        }
                      }}
                      placeholder="07:30 AM"
                      className={`w-full rounded-lg border bg-white px-2.5 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500 ${
                        slotDraft.start && !parseTimeInput(slotDraft.start)
                          ? "border-red-400"
                          : slotError && !slotDraft.start
                          ? "border-red-400 bg-red-50"
                          : "border-gray-300"
                      }`}
                    />
                    {slotDraft.start && parseTimeInput(slotDraft.start) && (
                      <p className="mt-1 text-[10px] text-emerald-600">
                        {to12Hour(parseTimeInput(slotDraft.start))}
                      </p>
                    )}
                    {slotDraft.start && !parseTimeInput(slotDraft.start) && (
                      <p className="mt-1 text-[10px] text-red-500">
                        Invalid time
                      </p>
                    )}
                  </div>
                  <div className="sm:col-span-3">
                    <label className="mb-1 block text-[10px] font-medium text-gray-500">
                      End time
                    </label>
                    <input
                      type="text"
                      value={slotDraft.end}
                      onChange={(e) =>
                        setSlotDraft((s) => ({ ...s, end: e.target.value }))
                      }
                      onBlur={() => {
                        const parsed = parseTimeInput(slotDraft.end);
                        if (parsed && parsed !== slotDraft.end) {
                          setSlotDraft((s) => ({ ...s, end: to12Hour(parsed) }));
                        }
                      }}
                      placeholder={`Auto (${slotDraft.start ? autoEndLabel : "based on duration"})`}
                      className={`w-full rounded-lg border bg-white px-2.5 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500 ${
                        slotDraft.end && !parseTimeInput(slotDraft.end)
                          ? "border-red-400"
                          : "border-gray-300"
                      }`}
                    />
                    <p className="mt-1 text-[10px] text-gray-500">
                      {slotDraft.end
                        ? parseTimeInput(slotDraft.end)
                          ? to12Hour(parseTimeInput(slotDraft.end))
                          : "Invalid time"
                        : "Leave blank for auto"}
                    </p>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-[10px] font-medium text-gray-500">
                      Label
                    </label>
                    <input
                      type="text"
                      value={slotDraft.label}
                      onChange={(e) =>
                        setSlotDraft((s) => ({ ...s, label: e.target.value }))
                      }
                      placeholder="Lunch"
                      className="w-full rounded-lg border border-gray-300 bg-white px-2.5 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-[10px] font-medium text-gray-500">
                      Limit (persons)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={slotDraft.capacity}
                      onChange={(e) =>
                        setSlotDraft((s) => ({ ...s, capacity: e.target.value }))
                      }
                      placeholder="0 = unlimited"
                      className="w-full rounded-lg border border-gray-300 bg-white px-2.5 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                  <div className="flex items-end sm:col-span-2">
                    <button
                      type="button"
                      onClick={addSlot}
                      className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-gray-800 px-3 py-2 text-sm font-medium text-white hover:bg-gray-900"
                    >
                      <Plus className="h-4 w-4" /> Add Slot
                    </button>
                  </div>
                </div>

                {form.slot_times.length > 0 && (
                  <div className="mt-3 space-y-1.5 border-t border-gray-200 pt-3">
                    {form.slot_times.map((t, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2.5 rounded-lg bg-white px-3 py-2 text-xs text-gray-700 ring-1 ring-gray-200"
                      >
                        <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                          <Check className="h-3 w-3" />
                        </span>
                        <span className="font-semibold text-gray-900">
                          {to12Hour(t.start)}
                          {t.end ? ` – ${to12Hour(t.end)}` : ""}
                        </span>
                        {t.label && (
                          <span className="truncate rounded bg-gray-100 px-1.5 py-0.5 text-[10px] text-gray-600">
                            {t.label}
                          </span>
                        )}
                        {t.capacity > 0 && (
                          <span className="shrink-0 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700">
                            {t.capacity} limit
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => removeSlot(i)}
                          className="ml-auto shrink-0 rounded p-0.5 text-gray-400 hover:bg-red-50 hover:text-red-600"
                          title="Remove slot"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={form.is_active}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, is_active: e.target.checked }))
                  }
                  className="h-4 w-4 rounded border-gray-300 text-red-600 focus:ring-red-500"
                />
                Active
              </label>
            </div>

            <div className="flex gap-3 border-t border-gray-200 px-5 py-4">
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 rounded-lg bg-red-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60"
              >
                {saving ? "Saving..." : editing ? "Update" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SevaPackages;
